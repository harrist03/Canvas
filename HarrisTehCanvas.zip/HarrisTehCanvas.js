let radius = 10
let canvas = null
let effectApplied = false
let ctx = null
let offscreenCanvas = null
let offscreenCanvasCtx = null
let imageWidth = 100
let imageHeight = 100
let imageX = 250
let imageY = 250
let image1 = new Image()
image1.src = "bmwm5.jpg"
let image2 = new Image()
image2.src = "porsche911.jpg"


let images = [
    { src: image1, x: 20, y: 20, width: 200, height: 150, rotation: 0, greyscale: false, brightness: 0, invert: false, posterize: false, threshold: false, sepia: false, redHue: 0, greenHue: 0, blueHue: 0, emboss: false, blur: false, sharpen: false, textMask: false },
    { src: image2, x: 250, y: 300, width: 200, height: 150, rotation: 0, greyscale: false, brightness: 0, invert: false, posterize: false, threshold: false, sepia: false, redHue: 0, greenHue: 0, blueHue: 0, emboss: false, blur: false, sharpen: false, textMask: false },
]

let imagesArray = [image1, image2]


let imageCanvasG
let imageCanvas
let scribbleCanvas
let scribbleCanvasCtx

let convolutionMatrices = {
    embossConvolutionMatrix: [0, 0, 0, 0, 2, -1, 0, -1, 0],
    blurConvolutionMatrix: [1, 2, 1, 2, 4, 2, 1, 2, 1],
    sharpenConvolutionMatrix: [0, -2, 0, -2, 11, -2, 0, -2, 0],
}

let currentImageIndex = 0

let offsetX = 0
let offsetY = 0

let eraserEnabled = false
let scribbleEnabled = false

let texts = []
let userText = ""
let textX = 50
let textY = 50
let isMovingText = false
let currentTextIndex = null
let isSelected = false



window.onload = onAllAssetsLoaded
function onAllAssetsLoaded() {
    canvas = document.getElementById("ht_canvas")
    ctx = canvas.getContext("2d")
    canvas.width = canvas.clientWidth
    canvas.height = canvas.clientHeight

    offscreenCanvas = document.createElement('canvas')
    offscreenCanvasCtx = offscreenCanvas.getContext('2d')
    offscreenCanvas.width = canvas.clientWidth
    offscreenCanvas.height = canvas.clientHeight

    scribbleCanvas = document.createElement('canvas')
    scribbleCanvasCtx = scribbleCanvas.getContext('2d')
    scribbleCanvas.width = canvas.clientWidth
    scribbleCanvas.height = canvas.clientHeight

    scribbleCanvasCtx.fillStyle = "red"
    document.getElementById("ht_colourPicker").value = "#ff0000"

    renderCanvas()

    canvas.addEventListener('mousedown', mousedownHandler)
    canvas.addEventListener('mousemove', moveHandler)
    canvas.addEventListener('mouseup', function (e) {
        isMovingText = false
    })
}


function renderCanvas() {
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.drawImage(scribbleCanvas, 0, 0, canvas.width, canvas.height)

    images.map((image, index) => {
        offscreenCanvasCtx.clearRect(0, 0, canvas.width, canvas.height)

        offscreenCanvasCtx.drawImage(image.src, image.x, image.y, image.width, image.height)

        let imageData = offscreenCanvasCtx.getImageData(image.x, image.y, image.width, image.height)

        // highlight current image
        if (index === currentImageIndex) {
            offscreenCanvasCtx.fillStyle = "rgba(0, 0, 0, 0.65)"
            offscreenCanvasCtx.fillRect(image.x - 2, image.y - 2, image.width + 4, image.height + 4)
        }

        // greyscale
        if (image.greyscale) {
            imageData = applyGreyscale(imageData)
        }
        // sepia
        if (image.sepia) {
            imageData = applySepia(imageData)
        }

        // brightness
        if (image.brightness !== 0) {
            imageData = applyBrightness(imageData, image.brightness)
        }

        // apply invert filter
        if (image.invert) {
            imageData = applyInvert(imageData)
        }

        // apply posterize filter
        if (image.posterize) {
            imageData = applyPosterize(imageData)
        }

        // apply threshold filter
        if (image.threshold) {
            imageData = applyThreshold(imageData)
        }
        // apply hue filter
        if (image.applyHue !== 0) {
            imageData = applyHue(imageData, image.redHue, image.greenHue, image.blueHue)
        }
        // apply emboss filter
        if (image.emboss) {
            imageData = applyConvolution(imageData, 'embossConvolutionMatrix')
        }
        // apply blur filter
        if (image.blur) {
            imageData = applyConvolution(imageData, 'blurConvolutionMatrix')
        }
        // apply sharpen filter
        if (image.sharpen) {
            imageData = applyConvolution(imageData, 'sharpenConvolutionMatrix')
        }

        // Draw the manipulated offscreen image onto the display canvas
        offscreenCanvasCtx.putImageData(imageData, image.x, image.y)
        // image rotation
        ctx.save()
        ctx.translate((image.x + image.width / 2), (image.y + image.height / 2))
        ctx.rotate(Math.radians(image.rotation))
        ctx.translate(-(image.x + image.width / 2), -(image.y + image.height / 2))

        // Draw the manipulated offscreen image onto the display canvas
        ctx.drawImage(offscreenCanvas, 0, 0, canvas.width, canvas.height)
        ctx.restore()

        // After all images are drawn, redraw the text
        for (let i = 0; i < texts.length; i++) {
            ctx.font = texts[i].fontSize + "px " + texts[i].fontFamily
            ctx.fillStyle = texts[i].colour
            if (texts[i].isSelected) {
                ctx.save() // Save the current state
                ctx.translate(texts[i].x, texts[i].y) // Move the origin to the stroke location
                ctx.rotate(texts[i].rotation * Math.PI / 180) // Rotate the canvas by the specified angle
                ctx.strokeStyle = "rgba(0, 0, 0, 0.65)"
                ctx.lineWidth = 1
                ctx.strokeRect(0, -30, ctx.measureText(texts[i].text).width, 30) // Draw the stroke at the new origin
                ctx.restore() // Restore the previous canvas state
            }
            // text rotation
            drawRotatedText(ctx, texts[i].text, texts[i].x, texts[i].y, texts[i].rotation)
        }
    })
}

function mousedownHandler(e) {
    if (scribbleEnabled || eraserEnabled) {
        return
    }
    let isOverText = false
    // when left mouse button is clicked
    if (e.which === 1) {
        let canvasBoundingRectangle = canvas.getBoundingClientRect()
        mouseX = e.clientX - canvasBoundingRectangle.left
        mouseY = e.clientY - canvasBoundingRectangle.top

        // set isSelected to false for all texts
        for (let i = 0; i < texts.length; i++) {
            texts[i].isSelected = false
        }

        // check if the mouse is over any of the texts
        for (let i = 0; i < texts.length; i++) {
            if (Math.abs(mouseX - texts[i].x) < 100 && Math.abs(mouseY - texts[i].y) < 30) {
                isMovingText = true
                currentTextIndex = i  // store the index of the text being moved
                currentImageIndex = null
                texts[i].isSelected = true
                isOverText = true
                // update the font size slider with the current selected text's font size
                document.getElementById('ht_fontSize').value = texts[currentTextIndex].fontSize
                document.getElementById('ht_textColour').value = texts[currentTextIndex].colour
                document.getElementById('ht_fontFamily').value = texts[currentTextIndex].fontFamily
                document.getElementById('ht_textRotation').value = texts[currentTextIndex].rotation
                break
            }
        }

        // if the mouse is not over any text, set isSelected to false for all texts
        if (!isOverText) {
            isMovingText = false
            currentImageIndex = null
            currentTextIndex = null
        } else {
            // if the mouse is over a text, do not allow the user to move the image
            return
        }

        for (let i = images.length - 1; i > -1; i--) {
            if (mouseIsInsideImage(images[i].x, images[i].y, images[i].width, images[i].height, mouseX, mouseY)) {
                offsetX = mouseX - images[i].x
                offsetY = mouseY - images[i].y
                currentImageIndex = i

                if (!effectApplied) {
                    renderCanvas()
                }

                // Update the controls with the current image's properties
                document.getElementById("ht_imageRotation").value = images[currentImageIndex].rotation
                document.getElementById("ht_brightness").value = images[currentImageIndex].brightness
                document.getElementById("ht_greyscale").checked = images[currentImageIndex].greyscale
                document.getElementById("ht_sepia").checked = images[currentImageIndex].sepia
                document.getElementById("ht_invert").checked = images[currentImageIndex].invert
                document.getElementById("ht_posterize").checked = images[currentImageIndex].posterize
                document.getElementById("ht_threshold").checked = images[currentImageIndex].threshold
                document.getElementById('ht_redHue').value = images[currentImageIndex].redHue
                document.getElementById('ht_greenHue').value = images[currentImageIndex].greenHue || 0
                document.getElementById('ht_blueHue').value = images[currentImageIndex].blueHue || 0
                document.getElementById('ht_emboss').checked = images[currentImageIndex].emboss
                document.getElementById('ht_blur').checked = images[currentImageIndex].blur
                document.getElementById('ht_sharpen').checked = images[currentImageIndex].sharpen
                document.getElementById('ht_textMask').checked = images[currentImageIndex].textMask
                break
            }
        }
    }
}


function moveHandler(e) {
    let canvasBoundingRectangle = canvas.getBoundingClientRect()
    mouseX = e.clientX - canvasBoundingRectangle.left
    mouseY = e.clientY - canvasBoundingRectangle.top
    if (!effectApplied) {
        if (e.which === 1) { // left mouse button
            // if the user is moving an image, update the image's position
            if (currentImageIndex !== null && !(eraserEnabled || scribbleEnabled)) {
                images[currentImageIndex].x = mouseX - offsetX
                images[currentImageIndex].y = mouseY - offsetY
                // else if the user is moving a text, update the text's position
            } else if (isMovingText && currentTextIndex !== null && !(eraserEnabled || scribbleEnabled)) {
                texts[currentTextIndex].x = mouseX
                texts[currentTextIndex].y = mouseY
                // else user can draw or erase on the canvas
            } else if (eraserEnabled || scribbleEnabled) {
                if (eraserEnabled) {
                    scribbleCanvasCtx.globalCompositeOperation = 'destination-out'
                } else {
                    scribbleCanvasCtx.globalCompositeOperation = 'source-over'
                }
                scribbleCanvasCtx.beginPath()
                scribbleCanvasCtx.arc(mouseX, mouseY, radius, 0, 2 * Math.PI)
                scribbleCanvasCtx.fill()
                scribbleCanvasCtx.closePath()
            }
            renderCanvas()
        }
    }
}

function clearScreen() {
    scribbleCanvasCtx.clearRect(0, 0, scribbleCanvas.width, scribbleCanvas.height)
    renderCanvas()
}

function color(newColor) {
    scribbleCanvasCtx.fillStyle = newColor
}

function radiusSize(newRadius) {
    radius = newRadius
}

function mouseIsInsideImage(imageTopLeftX, imageTopLeftY, imageWidth, imageHeight, x, y) {
    if ((x > imageTopLeftX) && (y > imageTopLeftY)) {
        if (x > imageTopLeftX) {
            if ((x - imageTopLeftX) > imageWidth) {
                return false // to the right of the image
            }
        }

        if (y > imageTopLeftY) {
            if ((y - imageTopLeftY) > imageHeight) {
                return false // below the image
            }
        }
    }
    else // above or to the left of the image
    {
        return false
    }
    return true // inside image
}

function applyBrightness(imageData, brightness) {
    let data = imageData.data

    for (let i = 0; i < data.length; i += 4) {
        data[i + 0] = data[i + 0] + brightness
        data[i + 1] = data[i + 1] + brightness
        data[i + 2] = data[i + 2] + brightness
        data[i + 3] = 255
    }

    return imageData
}

function applyGreyscale(imageData) {
    let data = imageData.data
    for (let i = 0; i < data.length; i += 4) {

        let grayscale = (data[i + 0] + data[i + 1] + data[i + 2]) / 3

        data[i + 0] = grayscale
        data[i + 1] = grayscale
        data[i + 2] = grayscale
        data[i + 3] = 255
    }

    return imageData
}

function applySepia(imageData) {
    let data = imageData.data
    for (let i = 0; i < data.length; i += 4) {
        let r = data[i]
        let g = data[i + 1]
        let b = data[i + 2]
        data[i] = Math.min(255, (r * 0.393) + (g * 0.769) + (b * 0.189))
        data[i + 1] = Math.min(255, (r * 0.349) + (g * 0.686) + (b * 0.168))
        data[i + 2] = Math.min(255, (r * 0.272) + (g * 0.534) + (b * 0.131))
    }

    return imageData
}

function applyInvert(imageData) {
    let data = imageData.data
    for (let i = 0; i < data.length; i += 4) {
        data[i] = 255 - data[i]
        data[i + 1] = 255 - data[i + 1]
        data[i + 2] = 255 - data[i + 2]
    }

    return imageData
}

function applyPosterize(imageData) {
    let data = imageData.data

    for (let i = 0; i < data.length; i += 4) {
        data[i + 0] = data[i + 0] - data[i + 0] % 64
        data[i + 1] = data[i + 1] - data[i + 1] % 64
        data[i + 2] = data[i + 2] - data[i + 2] % 64
        data[i + 3] = 255
    }

    return imageData
}

function applyThreshold(imageData) {
    let data = imageData.data

    for (let i = 0; i < data.length; i += 4) {
        for (let rgb = 0; rgb < 3; rgb++) {
            if (data[i + rgb] < 128) {
                data[i + rgb] = 0
            } else {
                data[i + rgb] = 255
            }
        }
        data[i + 3] = 255
    }

    return imageData
}

function setImageRotation(newRotationDegrees) {
    images[currentImageIndex].rotation = parseInt(newRotationDegrees)
    renderCanvas()
}


function setBrightness(newBrightness) {
    images[currentImageIndex].brightness = parseInt(newBrightness)
    renderCanvas()
}

function toggleGreyscale(greyscaleValue) {
    images[currentImageIndex].greyscale = greyscaleValue
    renderCanvas()
}

function toggleSepia(sepiaValue) {
    images[currentImageIndex].sepia = sepiaValue
    renderCanvas()
}

function toggleInvert(invertValue) {
    images[currentImageIndex].invert = invertValue
    renderCanvas()
}

function togglePosterize(posterizeValue) {
    images[currentImageIndex].posterize = posterizeValue
    renderCanvas()
}

function toggleThreshold(thresholdValue) {
    images[currentImageIndex].threshold = thresholdValue
    renderCanvas()
}

function applyEmboss(checked) {
    images[currentImageIndex].emboss = checked
    renderCanvas()
}

function applyBlur(checked) {
    images[currentImageIndex].blur = checked
    renderCanvas()
}

function applySharpen(checked) {
    images[currentImageIndex].sharpen = checked
    renderCanvas()
}

// Convert from degrees to radians.
Math.radians = function (degrees) {
    return degrees * Math.PI / 180
}

function handleFileSelect(event) {
    let file = event.target.files[0]
    let url = URL.createObjectURL(file)
    document.getElementById('ht_imageFile').dataset.url = url
}

function addImageFromInput() {
    let url = document.getElementById('ht_imageFile').dataset.url
    let newImage = addImage(url, 50, 50, 200, 150, 0, false, 0, false, false, false, false, 0, 0, 0)
    imagesArray.push(newImage)
}

function addImage(src, x, y, width, height, rotation, greyscale, brightness, invert, posterize, applyThreshold, sepia, redHue, greenHue, blueHue, emboss, blur, sharpen) {
    let img = new Image()
    img.onload = function () {
        images.push({
            src: img,
            x: x,
            y: y,
            width: width,
            height: height,
            rotation: rotation,
            greyscale: greyscale,
            brightness: brightness,
            invert: false,
            posterize: false,
            applyThreshold: false,
            sepia: false,
            redHue: 0,
            greenHue: 0,
            blueHue: 0,
            emboss: false,
            blur: false,
            sharpen: false
        })
        renderCanvas()
    }
    img.src = src

    return img
}

// Function to delete an image from the canvas
function deleteImage() {
    if (currentImageIndex !== null) {
        images.splice(currentImageIndex, 1)

        currentImageIndex = null

        renderCanvas()
    }
}


function updateImageSize(newWidth, newHeight) {
    if (currentImageIndex !== null) {
        images[currentImageIndex].width = newWidth
        images[currentImageIndex].height = newHeight
        renderCanvas()
    }
}

// Function to update the hue of the selected image
function updateImageHue(redHue, greenHue, blueHue) {
    if (currentImageIndex !== null) {
        images[currentImageIndex].redHue = redHue
        images[currentImageIndex].greenHue = greenHue
        images[currentImageIndex].blueHue = blueHue
        renderCanvas()
    }
}

function updateHue() {
    let redHue = parseInt(document.getElementById("ht_redHue").value)
    let greenHue = parseInt(document.getElementById("ht_greenHue").value)
    let blueHue = parseInt(document.getElementById("ht_blueHue").value)
    updateImageHue(redHue, greenHue, blueHue)
}

function applyHue(imageData, redHue, greenHue, blueHue) {
    let data = imageData.data

    for (let i = 0; i < data.length; i += 4) {
        data[i + 0] += redHue
        data[i + 1] += greenHue
        data[i + 2] += blueHue
    }
    return imageData
}

function sourceIn(isChecked) {
    canvas = document.getElementById('ht_canvas')
    ctx = canvas.getContext('2d')

    // clear the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    if (isChecked) {
        ctx.beginPath()
        ctx.fillRect(20, 20, 180, 120)
        ctx.closePath()

        // 2) select the alpha composite
        ctx.globalCompositeOperation = 'source-in'

        // 3) draw the original image
        // only the part that overlaps the alpha area will be visible
        ctx.drawImage(imagesArray[currentImageIndex], 20, 20, 200, 200)

        effectApplied = true
    } else {
        resetCanvas()
    }
}

function resetCanvas() {
    effectApplied = false
    // 1) Reset the globalCompositeOperation to 'source-over'
    ctx.globalCompositeOperation = 'source-over'

    // 2) Clear the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // 3) Redraw all your images at their original positions
    for (let i = 0; i < images.length; i++) {
        let img = images[i]
        if (img && img.complete) {
            ctx.drawImage(img, img.originalX, img.originalY, img.width, img.height)
        } else if (img) {
            img.onload = function () {
                ctx.drawImage(img, img.originalX, img.originalY, img.width, img.height)
            }
        } else {
            console.error('Image at index ' + i + ' is undefined')
        }
    }

    ctx.font = '30px Arial'
    for (let i = 0; i < texts.length; i++) {
        ctx.fillText(texts[i].text, texts[i].originalX, texts[i].originalY)
    }

    renderCanvas()
}

function applyTextMask(isChecked) {
    // Add a text mask
    if (isChecked) {
        ctx.clearRect(0, 0, canvas.width, canvas.height)
        // ctx.clearRect(images[currentImageIndex].x, images[currentImageIndex].y, images[currentImageIndex].width, images[currentImageIndex].height);
        // 1) define the alpha area   
        ctx.beginPath()
        ctx.font = "150px Times Roman"
        // text, x, y
        ctx.fillText("DkIT", 100, 320)
        ctx.closePath()

        // 2) select the alpha composite
        ctx.globalCompositeOperation = 'source-in'

        // 3) draw the original image
        // only the part that overlaps the alpha area will be visible
        ctx.drawImage(imagesArray[currentImageIndex], 0, 0, canvas.width, canvas.height);

        effectApplied = true
    } else {
        resetCanvas()
    }
}

function applyImageMask(isChecked) {
    canvas = document.getElementById('ht_canvas')
    ctx = canvas.getContext('2d')

    // Clear the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Add an image mask
    if (isChecked) {
        // 1) define the alpha area   
        ctx.beginPath()
        let maskImage = new Image()
        // image that will be used as a mask
        maskImage.src = 'bing.png'
        maskImage.onload = function () {
            ctx.drawImage(maskImage, 0, 0, canvas.width, canvas.height)
            ctx.closePath()

            // 2) select the alpha composite
            ctx.globalCompositeOperation = 'source-in'

            // 3) draw the original image
            // only the part that overlaps the alpha area will be visible
            ctx.drawImage(imagesArray[currentImageIndex], 0, 0, canvas.width, canvas.height)
        }
        effectApplied = true
    } else {
        resetCanvas()
    }
}
function applyBlendingOperation(operation) {
    let imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
    let data = imageData.data
    effectApplied = true

    for (let i = 0; i < data.length; i += 4) {
        let red = data[i]
        let green = data[i + 1]
        let blue = data[i + 2]

        if (operation === 'lighter') {
            // Increase the RGB values to make the image lighter
            data[i] = Math.min(255, red + 50)
            data[i + 1] = Math.min(255, green + 50)
            data[i + 2] = Math.min(255, blue + 50)
        } else if (operation === 'darker') {
            // Decrease the RGB values to make the image darker
            data[i] = Math.max(0, red - 50)
            data[i + 1] = Math.max(0, green - 50)
            data[i + 2] = Math.max(0, blue - 50)
        }
    }

    // Put the modified image data back on the canvas
    ctx.putImageData(imageData, 0, 0)

    if (operation === 'normal') {
        effectApplied = false
        resetCanvas()
    }
}

function applyConvolution(imageData, matrixName) {
    let data = imageData.data
    let originalData = data.slice()
    let convolutionMatrix = convolutionMatrices[matrixName]

    let totalConvolutionSum = convolutionMatrix.reduce((a, b) => a + b, 0)

    for (let i = 0; i < data.length; i += 4) {
        data[i + 3] = 255 // alpha

        // apply the convolution for each of red, green and blue
        for (let rgbOffset = 0; rgbOffset < 3; rgbOffset++) {
            // get the pixel and its eight surrounding pixel values from the original image 
            let convolutionPixels = [
                originalData[i + rgbOffset - canvas.width * 4 - 4],
                originalData[i + rgbOffset - canvas.width * 4],
                originalData[i + rgbOffset - canvas.width * 4 + 4],
                originalData[i + rgbOffset - 4],
                originalData[i + rgbOffset],
                originalData[i + rgbOffset + 4],
                originalData[i + rgbOffset + canvas.width * 4 - 4],
                originalData[i + rgbOffset + canvas.width * 4],
                originalData[i + rgbOffset + canvas.width * 4 + 4]
            ]

            // do the convolution
            let convolvedPixel = 0
            for (let j = 0; j < 9; j++) {
                convolvedPixel += convolutionPixels[j] * convolutionMatrix[j]
            }

            // place the convolved pixel in the double buffer		 
            if (convolutionMatrix === convolutionMatrices['embossConvolutionMatrix']) { // embossed is treated differently
                data[i + rgbOffset] = convolvedPixel + 127
            } else {
                convolvedPixel /= totalConvolutionSum
                data[i + rgbOffset] = convolvedPixel
            }
        }
    }

    return imageData
}

function applyText() {
    let canvas = document.getElementById('ht_canvas')
    let ctx = canvas.getContext('2d')
    let userText = document.getElementById('ht_text').value
    let fontFamily = document.getElementById('ht_fontFamily').value
    let fontColour = document.getElementById('ht_textColour').value
    let fontSize = document.getElementById('ht_fontSize').value

    // Store the text and its position in the array
    texts.push({ text: userText, x: textX, y: textY, fontFamily: fontFamily, colour: fontColour, fontSize: fontSize, rotation: 0 })

    // Clear the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    renderCanvas()

    // clear input field
    document.getElementById('ht_text').value = ""
}

function deleteText() {
    if (currentTextIndex !== null) {
        texts.splice(currentTextIndex, 1)
    }

    currentTextIndex = null

    renderCanvas()
}

function toggleEraser() {
    eraserEnabled = !eraserEnabled;
    applyEraser(eraserEnabled);
}

function toggleScribble() {
    scribbleEnabled = !scribbleEnabled;
    applyScribble(scribbleEnabled);
}

// apply scribble and eraser
function applyEraser(checked) {
    let eraserElement = document.getElementById('ht_eraser')
    let scribbleElement = document.getElementById('ht_scribble')
    eraserEnabled = checked
    if (eraserEnabled) {
        eraserElement.style.border = '1px solid white';
        scribbleElement.style.border = '';
        canvas.style.cursor = 'url(eraser.svg), auto';
        document.getElementById('ht_scribble').checked = false;
        scribbleEnabled = false;
    } else if (document.getElementById('ht_scribble').checked) {
        canvas.style.cursor = 'url(brush_icon.svg), auto';
        eraserElement.style.border = '';
        scribbleElement.style.border = '1px solid white';
    } else {
        eraserElement.style.border = '';
        scribbleElement.style.border = '';
        canvas.style.cursor = 'default';
    }
}

function applyScribble(checked) {
    let eraserElement = document.getElementById('ht_eraser')
    let scribbleElement = document.getElementById('ht_scribble')
    scribbleEnabled = checked
    if (scribbleEnabled) {
        scribbleElement.style.border = '1px solid white';
        eraserElement.style.border = '';
        canvas.style.cursor = 'url(brush_icon.svg), auto'
        document.getElementById('ht_eraser').checked = false
        eraserEnabled = false
    } else if (eraserEnabled) {
        scribbleElement.style.border = '';
        eraserEnabled.style.border = '1px solid white';
        canvas.style.cursor = 'url(eraser.svg), auto'
    } else {
        canvas.style.cursor = 'default'
        eraserElement.style.border = '';
        scribbleElement.style.border = '';  
    }
}

// Function to modify the text size after the user has entered the text
function setFontSize(newFontSize) {
    if (currentTextIndex !== null) {
        texts[currentTextIndex].fontSize = parseInt(newFontSize)
    }
    renderCanvas()
}

function setTextColour(newTextColour) {
    if (currentTextIndex !== null) {
        texts[currentTextIndex].colour = newTextColour
    }
    renderCanvas()
}

function setFontFamily(newFont) {
    if (currentTextIndex !== null) {
        texts[currentTextIndex].fontFamily = newFont
    }
    renderCanvas()
}

function setTextRotation(newRotationDegrees) {
    texts[currentTextIndex].rotation = parseInt(newRotationDegrees)
    renderCanvas()
}

function drawRotatedText(ctx, text, x, y, angle) {
    ctx.save() // Save the current state
    ctx.translate(x, y) // Move the origin to the text location
    ctx.rotate(angle * Math.PI / 180) // Rotate the canvas by the specified angle
    ctx.fillText(text, 0, 0) // Draw the text at the new origin
    ctx.restore() // Restore the previous canvas state
}

function moveImageToFront() {
    if (currentImageIndex < images.length - 1) {
        const temp = images[currentImageIndex]
        images[currentImageIndex] = images[currentImageIndex + 1]
        images[currentImageIndex + 1] = temp
    }
}

function moveImageToBack() {
    if (currentImageIndex > 0) {
        const temp = images[currentImageIndex]
        images[currentImageIndex] = images[currentImageIndex - 1]
        images[currentImageIndex - 1] = temp
    }
}

function moveTextToFront() {
    if (currentTextIndex < texts.length - 1) {
        const temp = texts[currentTextIndex]
        texts[currentTextIndex] = texts[currentTextIndex + 1]
        texts[currentTextIndex + 1] = temp
    }
}

function moveTextToBack() {
    if (currentTextIndex > 0) {
        const temp = texts[currentTextIndex]
        texts[currentTextIndex] = texts[currentTextIndex - 1]
        texts[currentTextIndex - 1] = temp
    }
}